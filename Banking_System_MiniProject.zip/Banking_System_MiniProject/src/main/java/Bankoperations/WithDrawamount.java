package Bankoperations;

import BankBluePrint.UserBankDetails;

public interface WithDrawamount {
    void WithDrawlogic(UserBankDetails accounts,double amount);
}
