package Bankoperations;

import BankBluePrint.UserBankDetails;

public interface Transferamount {
    public static void transferAmount(UserBankDetails source, UserBankDetails destination, double amount) {

    }
}
