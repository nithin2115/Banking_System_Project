package Bankoperations.InterfaceLogics;

import BankBluePrint.UserBankDetails;
import Bankoperations.InterfaceLogics.TransferLogic;
//Blueprint for Multithreading
public class TransferTask implements Runnable {
    private UserBankDetails source;
    private UserBankDetails dest;
    private double amount;

    public TransferTask(UserBankDetails source, UserBankDetails dest, double amount) {
        this.source = source;
        this.dest = dest;
        this.amount = amount;
    }

    @Override
    public void run() {
        try {
            TransferLogic.transferAmount(source, dest, amount);
        } catch (Exception e) {
            System.err.println("Transfer Error: " + e.getMessage());
        }
    }
}
