package Bankoperations.InterfaceLogics;

import BankBluePrint.UserBankDetails;
import Bankoperations.Transferamount;
import Exceptionlogic.AccountNotFoundException;

public class TransferLogic implements Transferamount {

    public static void transferAmount(UserBankDetails source, UserBankDetails dest, double amount) {
        if (source == null) {
            throw new AccountNotFoundException("Source account not found!");
        }
        if (dest == null) {
            throw new AccountNotFoundException("Destination account not found!");
        }
        if (amount <= 0) {
            System.out.println("Transfer amount must be greater than zero.");
            return;
        }


        Object firstLock = null;
        Object secondLock=null;
        if (source.getCid() < dest.getCid()) {
            firstLock = source;
            secondLock = dest;
        } else {
            firstLock = dest;
            secondLock = source;
        }

        synchronized (firstLock) {
            synchronized (secondLock) {
                if (source.getBalance() < amount) {
                    System.out.println("Insufficient balance in source account.");
                    return;
                }
                source.setBalance(source.getBalance() - amount);
                dest.setBalance(dest.getBalance() + amount);

                System.out.println("Transfer successful!");
                System.out.println("Source balance: " + source.getBalance());
                System.out.println("Destination balance: " + dest.getBalance());
            }
        }
    }
}
