package Bankoperations.InterfaceLogics;

import BankBluePrint.UserBankDetails;
import Bankoperations.Finalbalance;
import Exceptionlogic.AccountNotFoundException;

public class FinalBalanceLogic implements Finalbalance {
    @Override
    public void balanceamount(UserBankDetails account) {
        if(account==null){
            throw new AccountNotFoundException("");
        }

        System.out.println("Account Details:");
        System.out.println("Account Holder: " + account.getName());
        System.out.println("Account Number: " + account.getAccountnumber());
        System.out.println("Current Balance:" + account.getBalance());

    }
}
