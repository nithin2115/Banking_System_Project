package Bankoperations.InterfaceLogics;

import BankBluePrint.UserBankDetails;
import Bankoperations.Deposit;
import Exceptionlogic.InsufficientAmountException;

public class DepositLogic implements Deposit {

    @Override
    public void Depositamount(UserBankDetails account, double amount) {
        if (account == null) {
            throw new IllegalArgumentException("Account cannot be null.");
        }
        try {
            if (amount < 1000) {
                throw new InsufficientAmountException("Amount should be greater than ₹1000 to deposit.");
            }
            synchronized (account) {
                double newBalance = account.getBalance() + amount;
                account.setBalance(newBalance);
            }
            System.out.println("Deposit successful. New balance: " + account.getBalance());
        } catch (InsufficientAmountException e) {
            System.out.println(e.getMessage());
        }
    }

}

