package Bankoperations.InterfaceLogics;

import BankBluePrint.UserBankDetails;
import Bankoperations.WithDrawamount;
import Exceptionlogic.InsufficientAmountException;
import Exceptionlogic.InsufficientBalanceException;

public class WithDrawLogic implements WithDrawamount {

    @Override
    public void WithDrawlogic(UserBankDetails accounts, double amount) {
        try{
            if(amount<0){
                System.out.println("Amount should be positive.");
            }
        }catch (Exception e){
                System.out.println(e.getMessage());
        }
        if(amount>accounts.getBalance()){
            throw new InsufficientBalanceException("");
        }
        double newbalance=accounts.getBalance()-amount;
        accounts.setBalance(newbalance);
        System.out.println("Withdrawal Money Succesfully remaining balance "+ accounts.getBalance());
    }
}
