package Bankoperations;

import BankBluePrint.UserBankDetails;

public interface Finalbalance {
    void balanceamount(UserBankDetails account);
}
