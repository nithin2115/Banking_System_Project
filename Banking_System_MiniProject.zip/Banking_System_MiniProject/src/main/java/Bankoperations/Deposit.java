package Bankoperations;

import BankBluePrint.UserBankDetails;

public interface Deposit {
    public void Depositamount(UserBankDetails account, double amount);


}
