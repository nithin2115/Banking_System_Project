package BankBluePrint;
import Bankoperations.InterfaceLogics.DepositLogic;
import Bankoperations.InterfaceLogics.TransferTask;
import Bankoperations.InterfaceLogics.WithDrawLogic;
import Bankoperations.InterfaceLogics.TransferLogic;
import Bankoperations.Transferamount;
import Exceptionlogic.AccountNotFoundException;
import Exceptionlogic.InsufficientAmountException;
import javax.naming.InvalidNameException;
import java.util.*;

public class UserAccountCreationLogic {

    //  helper method
    public static UserBankDetails findUserByName(List<UserBankDetails> users, String name) {
        for (UserBankDetails user : users) {
            if (user.getName().equalsIgnoreCase(name.trim())) {
                return user;
            }
        }
        return null;
    }
    //accountnumber helper
    public static UserBankDetails findUserByAccountnumber(List<UserBankDetails> users, String accountnumber) {
        for (UserBankDetails user : users) {
            if (user.getAccountnumber().equals(accountnumber)) {
                return user;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        List<UserBankDetails> li = new ArrayList<>();
        Random random = new Random();
        Scanner sc = new Scanner(System.in);

        // for Create multiple accounts
        System.out.print("How many accounts do you want to create? ");
        int numAccounts = sc.nextInt();
        sc.nextLine();

        for (int i = 0; i < numAccounts; i++) {
            try {
                System.out.print("Enter name for Account " + (i + 1) + ": ");
                String name = sc.nextLine().trim();
                if (name.isEmpty()) throw new InvalidNameException("Name cannot be empty!");

                char initials = Character.toUpperCase(name.charAt(0));
                int randomNum = 1000 + random.nextInt(9000);
                String finalAccountNum = String.valueOf(initials) + randomNum;

                UserBankDetails account = new UserBankDetails(name, finalAccountNum);
                li.add(account);

                System.out.println("Account created: " + account);

                System.out.print("Enter deposit amount for " + name + " : ");
                double depoAmount = sc.nextDouble();
                sc.nextLine();

                DepositLogic depositLogic = new DepositLogic(); // object creation for depositlogic
                depositLogic.Depositamount(account, depoAmount); // method calling

            } catch (Exception e) {
                System.err.println(e.getMessage());
                i--;
            }
        }

        System.out.print("Enter the name of account holder to withdraw: ");
        String withdrawName = sc.nextLine();
        UserBankDetails withdrawAccount = findUserByName(li, withdrawName);

        if (withdrawAccount != null) {
            System.out.print("Withdraw from " + withdrawAccount.getName() + "Enter amount : ");
            double withdrawAmount = sc.nextDouble();
            sc.nextLine();
            WithDrawLogic withdraw = new WithDrawLogic();
            withdraw.WithDrawlogic(withdrawAccount, withdrawAmount);
        } else {
            System.out.println("Account with name \"" + withdrawName + "\" not found!");
        }

        try {
            System.out.println("Enter details for fund transfer:");
            System.out.print("Source Account Number: ");
            String sourceAccNum = sc.nextLine();

            System.out.print("Destination Account Number: ");
            String destAccNum = sc.nextLine();

            System.out.print("Amount to Transfer: ");
            double amount = sc.nextDouble();
            sc.nextLine();
            UserBankDetails source = findUserByAccountnumber(li, sourceAccNum);
          UserBankDetails dest =     findUserByAccountnumber(li, destAccNum);

            Thread depositThread = new Thread(new TransferTask(source,dest,amount));
            depositThread.start();

        } catch (AccountNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (Exception ex) {
            System.err.println("Input or transfer error: " + ex.getMessage());
        }

        sc.close();

       // balances of users
        System.out.println("\nAccount Details:");
        for (UserBankDetails account : li) {
            System.out.println("Account Holder: " + account.getName());
            System.out.println("Account Number: " + account.getAccountnumber());
            System.out.println("Current Balance:" + account.getBalance());
            System.out.println("--------------------->");
        }
    }
}
