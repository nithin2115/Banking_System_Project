package BankBluePrint;

public class UserBankDetails {
    private String name;
    private String accountnumber;
    private double balance;
    private int cid;  // unique customer ID

    public UserBankDetails(String name, String accountnumber, double balance, int cid) {
        this.name = name;
        this.accountnumber = accountnumber;
        this.balance = balance;
        this.cid = cid;
    }

    public UserBankDetails(String name, String accountnumber) {
        this(name, accountnumber, 0.0, 0);
    }

    public int getCid() {
        return cid;
    }

    public void setCid(int cid) {
        this.cid = cid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountnumber() {
        return accountnumber;
    }


    public void setAccountnumber(String accountnumber) {
        this.accountnumber = accountnumber;
    }

    public synchronized double getBalance() {
        return balance;
    }

    public synchronized void setBalance(double balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "UserBankDetails{" +
                "name='" + name + '\'' +
                ", accountnumber='" + accountnumber + '\'' +
                ", balance=" + balance +
                ", cid=" + cid +
                '}';
    }
}
