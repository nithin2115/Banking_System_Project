package com;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication(scanBasePackages = "com")
@EnableMongoRepositories(basePackages = "com.repository")
public class BankingSystemSimulatorUsingApiApplication {
    private static final Logger log = LoggerFactory.getLogger(BankingSystemSimulatorUsingApiApplication.class);

	public static void main(String[] args) {
		SpringApplication.run(BankingSystemSimulatorUsingApiApplication.class, args);
        log.info("Bank Server is up");
	}

}
