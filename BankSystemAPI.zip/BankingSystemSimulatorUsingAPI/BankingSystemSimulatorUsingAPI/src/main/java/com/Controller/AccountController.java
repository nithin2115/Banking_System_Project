package com.Controller;

import com.Document.Account;
import com.dto.AccountRequest.CreateAccountRequest;
import com.dto.Responses.AccountResponse;
import com.dto.Responses.TransactionResponse;
import com.Transcation.Service.AccountService;

import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(value = "/api/accounts", produces = MediaType.APPLICATION_JSON_VALUE)
public class AccountController {

    private final AccountService accountService;
    private static final Logger log = LoggerFactory.getLogger(AccountController.class);
 // Constructor
    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }


    // CREATE ACCOUNT

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AccountResponse> createAccount(@Valid @RequestBody CreateAccountRequest request) {
        log.info("Creating account for holder: {}", request.getHolderName());

        Account account = accountService.createAccount(request.getHolderName());

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(AccountResponse.from(Optional.ofNullable(account)));
    }


    // GET ACCOUNT BY ACCOUNT NUMBER


    @GetMapping("/{accountNumber}")
    public ResponseEntity<AccountResponse> getAccount(@PathVariable String accountNumber) {

        log.info("Fetching account: {}", accountNumber);

        Account account = accountService.getAccount(accountNumber)
                .orElseThrow(() -> new RuntimeException("Account not found"));

        return ResponseEntity.ok(AccountResponse.from(Optional.ofNullable(account)));
    }


    // GET ALL TRANSACTIONS OF AN ACCOUNT

    @GetMapping("/{accountNumber}/transactions")
    public ResponseEntity<List<TransactionResponse>> getAccountTransactions(
            @PathVariable String accountNumber) {

        log.info("Fetching transactions for account: {}", accountNumber);

        List<TransactionResponse> responseList =
                accountService.getAllTransactionIds(accountNumber)
                        .stream()
                        .map(TransactionResponse::from)
                        .toList();

        return ResponseEntity.ok(responseList);
    }


    // UPDATE ACCOUNT

    @PatchMapping (value = "update", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<AccountResponse> updateAccount(@Valid @RequestBody Account request) {

        log.info("Updating account: {}", request.getAccountNumber());

        Account updated = accountService.updateAccount(request);

        return ResponseEntity.ok(AccountResponse.from(Optional.ofNullable(updated)));
    }

    // -------------------------------------------------------
    // DELETE ACCOUNT
    // -------------------------------------------------------
    @DeleteMapping(value = "delete/{accountNumber}")
    public ResponseEntity<Void> deleteAccount(@PathVariable String accountNumber) {

        log.info("Deleting account: {}", accountNumber);

        boolean deleted = accountService.deleteAccount(accountNumber);

        return deleted ?
                ResponseEntity.noContent().build() :
                ResponseEntity.notFound().build();
    }
}
