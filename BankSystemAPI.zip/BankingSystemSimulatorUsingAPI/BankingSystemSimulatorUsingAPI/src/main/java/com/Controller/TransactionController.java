package com.Controller;

import com.Document.Transcation;
import com.dto.AccountRequest.DepositRequest;
import com.dto.AccountRequest.TransferRequest;
import com.dto.Responses.TransactionResponse;
import com.Transcation.Service.TransactionService;

import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/api/accounts", produces = MediaType.APPLICATION_JSON_VALUE)
public class TransactionController {

    private final TransactionService transactionService;

    // Constructor Injection (clean and professional)
    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    // ---------------------------------------------------------
    // DEPOSIT MONEY
    // ---------------------------------------------------------
    @PutMapping("/{accountNumber}/deposit")
    public ResponseEntity<TransactionResponse> deposit(@PathVariable("accountNumber") String accountNumber, @Valid @RequestBody DepositRequest req) {

        Transcation transaction = transactionService.deposit(accountNumber, req.getBalance());

        return ResponseEntity.ok(TransactionResponse.from(transaction));
    }

    // ---------------------------------------------------------
    // WITHDRAW MONEY
    // ---------------------------------------------------------
    @PutMapping("/{accountNumber}/withdraw")
    public ResponseEntity<TransactionResponse> withdraw(@PathVariable String accountNumber, @Valid @RequestBody DepositRequest req) {

        Transcation transaction = transactionService.withdraw(accountNumber, req.getBalance());

        return ResponseEntity.ok(TransactionResponse.from(transaction));
    }

    // ---------------------------------------------------------
    // TRANSFER MONEY
    // ---------------------------------------------------------
    @PostMapping("/transfer")
    public ResponseEntity<TransactionResponse> transfer(@Valid @RequestBody TransferRequest req) {

        Transcation transaction = transactionService.transfer(
                req.getFromAccount(),
                req.getToAccount(),
                req.getAmount()
        );

        return ResponseEntity.status(HttpStatus.OK).body(TransactionResponse.from(transaction));
    }
}
