package com.Transcation.Service;

import com.Document.Account;
import com.Document.Transcation;
import com.Exceptions.AccountNotFoundException;
import com.repository.AccountRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class AccountServiceImp implements AccountService{
    private final AccountRepo accountRepo;

    public AccountServiceImp(AccountRepo accountRepo) {
        this.accountRepo = accountRepo;
    }

    private static final Logger log = LoggerFactory.getLogger(AccountServiceImp.class);
    @Override
    public Account createAccount(String name) {
        Account a =new Account();
        a.setAccountNumber(generateAccountNumber(name));
        a.setCreatedAt(LocalDateTime.now());
        a.setBalance(0);
        a.setStatus("ACTIVE");
        a.setHolderName(name);
        return accountRepo.save(a);
    }

    @Override
    public Optional<Account> getAccount(String accountNumber)  {
        try {
            return accountRepo.findByAccountNumber(accountNumber);
        } catch (Exception e) {
           throw new AccountNotFoundException("Account not found");
        }

    }
    @Override
    public List<Transcation> getAllTransactionIds(String accountId) {
        return accountRepo.findByAccountNumber(accountId).map(Account::getList).orElseGet(Collections::emptyList);

    }

    @Override
    public Account updateAccount(Account account) {
        Optional<Account> acc = accountRepo.findByAccountNumber(account.getAccountNumber());
        if (account.getHolderName() != null) {
            if (acc.isPresent()) {
                Account ac=acc.get();
               ac.setHolderName(account.getHolderName());
                if (account.getBalance() != 0) ac.setBalance(account.getBalance());
                accountRepo.save(ac);

            }
        }
        return  acc.get();
    }

    @Override
    public boolean deleteAccount(String accountNumber) {
        Optional<Account> acc = accountRepo.findByAccountNumber(accountNumber);
        if(acc.isPresent()){
            Account accFromDB = acc.get();
            accFromDB.setHolderName(null);
            accFromDB.setStatus("INACTIVE");
            accFromDB.setBalance(0);
            accountRepo.save(accFromDB);
            return true;
        }

        return false;
    }
    public String generateAccountNumber(String holderName) {
        String initials = holderName.trim().toUpperCase().substring(0, 2);
        int random = new Random().nextInt(9000) + 1000;
        return initials + random;
    }

}
