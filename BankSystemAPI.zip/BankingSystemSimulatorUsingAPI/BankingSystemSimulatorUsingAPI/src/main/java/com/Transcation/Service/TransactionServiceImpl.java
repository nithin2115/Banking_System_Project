package com.Transcation.Service;

import com.Document.Account;
import com.Document.Transcation;

import com.Exceptions.AccountNotFoundException;
import com.Exceptions.InvalidAmountException;
import com.Exceptions.InsufficientBalanceException;

import com.repository.AccountRepo;
import com.repository.TranscationRepo;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final AccountRepo accountRepo;
    private final TranscationRepo transcationRepo;
    List<Transcation> list = new ArrayList<>();

    public TransactionServiceImpl(AccountRepo accountRepo, TranscationRepo transcationRepo) {
        this.accountRepo = accountRepo;
        this.transcationRepo = transcationRepo;
    }

    // ---------------------------------------------------------
    // DEPOSIT
    // ---------------------------------------------------------
    @Override
    @Transactional
    public Transcation deposit(String accountNumber, double amount) {

        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be greater than 0");
        }

        Account account = accountRepo.findByAccountNumber(accountNumber).orElseThrow(() -> new AccountNotFoundException("Account not found: " + accountNumber));

        account.setBalance(account.getBalance() + amount);
//        accountRepo.save(account);

        Transcation tx = new Transcation();
        tx.setTransactionId(generateTransactionId());
        tx.setSourceAccount(accountNumber);
        tx.setDestinationAccount("-");
        tx.setType("DEPOSIT");
        tx.setStatus("Success");
        tx.setAmount(amount);
        tx.setTimestamp(LocalDateTime.now());
        list.add(tx);
        account.setList(list);
        accountRepo.save(account);
        return transcationRepo.save(tx);
    }

    // ---------------------------------------------------------
    // WITHDRAW
    // ---------------------------------------------------------
    @Override
    @Transactional
    public Transcation withdraw(String accountNumber, double amount) {

        if (amount <= 0) {
            throw new InvalidAmountException("Withdraw amount must be greater than 0");
        }

        Account account = accountRepo.findByAccountNumber(accountNumber).orElseThrow(() -> new AccountNotFoundException("Account not found: " + accountNumber));

        if (account.getBalance() < amount) {
            throw new InsufficientBalanceException("Insufficient balance");
        }

        account.setBalance(account.getBalance() - amount);
//        accountRepo.save(account);

        Transcation tx = new Transcation();
        tx.setTransactionId(generateTransactionId());
        tx.setSourceAccount(accountNumber);
        tx.setDestinationAccount("-");
        tx.setType("WITHDRAW");
        tx.setStatus("Success");
        tx.setAmount(amount);
        tx.setTimestamp(LocalDateTime.now());
        list.add(tx);
        account.setList(list);
        accountRepo.save(account);

        return transcationRepo.save(tx);
    }

    // ---------------------------------------------------------
    // TRANSFER
    // ---------------------------------------------------------
    @Override
    @Transactional
    public Transcation transfer(String fromAccount, String toAccount, double amount) {

        if (amount <= 0) {
            throw new InvalidAmountException("Transfer amount must be greater than 0");
        }

        if (fromAccount.equals(toAccount)) {
            throw new InvalidAmountException("From and To accounts cannot be the same");
        }

        Account sender = accountRepo.findByAccountNumber(fromAccount).orElseThrow(() -> new AccountNotFoundException("Sender account not found"));

        Account receiver = accountRepo.findByAccountNumber(toAccount).orElseThrow(() -> new AccountNotFoundException("Receiver account not found"));

        if (sender.getBalance() < amount) {
            throw new InsufficientBalanceException("Insufficient balance for transfer");
        }

        // Update balances
        sender.setBalance(sender.getBalance() - amount);
        receiver.setBalance(receiver.getBalance() + amount);

//        accountRepo.save(sender);
//        accountRepo.save(receiver);

        // Save transfer record
        Transcation tx = new Transcation();
        tx.setSourceAccount(fromAccount);
        tx.setDestinationAccount(toAccount);
        tx.setType("TRANSFER");
        tx.setStatus("Success");
        tx.setTransactionId(generateTransactionId());
        tx.setAmount(amount);
        tx.setTimestamp(LocalDateTime.now());
        list.add(tx);
        sender.setList(list);
        accountRepo.save(sender);
        receiver.setList(list);
        accountRepo.save(receiver);

        return transcationRepo.save(tx);
    }
        private String generateTransactionId() {
            int seq = nextSequence();
            String date = java.time.LocalDate.now().toString().replace("-", "");
            return "TXN-" + date + "-" + String.format("%03d", seq);
        }

    LocalDate lastDate = LocalDate.now();
    int sequence = 0;

    public synchronized int nextSequence() {
        LocalDate today = LocalDate.now();
        if (!today.equals(lastDate)) {
            sequence = 0; // reset sequence for new day
            lastDate = today;
        }
        sequence++;
        return sequence;
    }
}
