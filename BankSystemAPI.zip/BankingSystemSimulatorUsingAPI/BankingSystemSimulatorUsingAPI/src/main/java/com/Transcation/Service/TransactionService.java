package com.Transcation.Service;

import com.Document.Transcation;

public interface TransactionService {

    Transcation deposit(String accountNumber, double amount);

    Transcation withdraw(String accountNumber, double amount);

    Transcation transfer(String fromAccount, String toAccount, double amount);
}
