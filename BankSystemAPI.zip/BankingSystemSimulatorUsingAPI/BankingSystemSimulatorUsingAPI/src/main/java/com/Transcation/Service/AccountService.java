package com.Transcation.Service;

import com.Document.Account;
import com.Document.Transcation;


import java.util.List;
import java.util.Optional;

public interface AccountService {
    Account createAccount(String name);
    Optional<Account> getAccount(String accountNumber);
    List<Transcation> getAllTransactionIds(String accountId);
    Account updateAccount(Account account);
    boolean deleteAccount(String accountNumber);

}
