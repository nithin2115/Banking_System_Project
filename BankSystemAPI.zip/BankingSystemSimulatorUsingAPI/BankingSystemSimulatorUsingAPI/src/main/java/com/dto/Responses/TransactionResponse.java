package com.dto.Responses;


import com.Document.Transcation;
import org.springframework.boot.autoconfigure.pulsar.PulsarProperties;

public class TransactionResponse {

    private String transactionId;
    private String type;
    private double amount;
    private String timestamp;
    private String status;
    private String sourceAccount;
    private String destinationAccount;

    public static TransactionResponse from(Transcation t) {
        TransactionResponse res = new TransactionResponse(); // object creation

        res.transactionId = t.getTransactionId();
        res.type = t.getType();
        res.amount = t.getAmount();
        res.status = t.getStatus();
        res.sourceAccount = t.getSourceAccount();
        res.destinationAccount = t.getDestinationAccount();

        if (t.getTimestamp() != null)
            res.timestamp = t.getTimestamp().toString();

        return res;
    }

    public String getTransactionId() { return transactionId; }
    public String getType() { return type; }
    public double getAmount() { return amount; }
    public String getTimestamp() { return timestamp; }
    public String getStatus() { return status; }
    public String getSourceAccount() { return sourceAccount; }
    public String getDestinationAccount() { return destinationAccount; }
}

