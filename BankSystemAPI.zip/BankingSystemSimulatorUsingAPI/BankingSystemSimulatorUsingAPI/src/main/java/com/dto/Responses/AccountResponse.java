package com.dto.Responses;

import com.Document.Account;

import java.util.Optional;

public class AccountResponse {

    private String accountNumber;
    private String holderName;
    private double balance;
    private String status;
    private String createdAt;

    public static AccountResponse from(Optional<Account> account) {
        AccountResponse res = new AccountResponse(); // obj creation for class

        res.accountNumber = account.get().getAccountNumber();
        res.holderName = account.get().getHolderName();
        res.balance = account.get().getBalance();
        res.status = account.get().getStatus();

        if (account.get().getCreatedAt() != null)
            res.createdAt = account.get().getCreatedAt().toString();

        return res;
    }

    public String getAccountNumber() { return accountNumber; }
    public String getHolderName() { return holderName; }
    public double getBalance() { return balance; }
    public String getStatus() { return status; }
    public String getCreatedAt() { return createdAt; }
}

