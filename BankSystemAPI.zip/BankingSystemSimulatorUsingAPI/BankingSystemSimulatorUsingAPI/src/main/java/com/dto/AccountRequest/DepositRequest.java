package com.dto.AccountRequest;

import jakarta.validation.constraints.Positive;

public class DepositRequest {
    @Positive(message = "Amount should be Positive")
    private double balance;

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
