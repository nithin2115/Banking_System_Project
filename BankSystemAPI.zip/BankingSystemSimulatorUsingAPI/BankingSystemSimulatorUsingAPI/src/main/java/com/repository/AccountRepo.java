package com.repository;

import com.Document.Account;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

// link transcations to acccounts
@Repository
public interface AccountRepo extends MongoRepository<Account,String> {
    Optional<Account> findByAccountNumber(String accountNumber);
}
